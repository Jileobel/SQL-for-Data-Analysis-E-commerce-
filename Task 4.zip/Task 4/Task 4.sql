CREATE DATABASE ecommerce_db;
USE ecommerce_db;

CREATE TABLE customers (
    customer_id INT PRIMARY KEY,
    customer_name VARCHAR(100),
    city VARCHAR(50),
    country VARCHAR(50)
);

CREATE TABLE products (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(100),
    category VARCHAR(50),
    price DECIMAL(10,2)
);

CREATE TABLE orders (
    order_id INT PRIMARY KEY,
    customer_id INT,
    order_date DATE,
    FOREIGN KEY (customer_id)
    REFERENCES customers(customer_id)
);

CREATE TABLE order_details (
    detail_id INT PRIMARY KEY,
    order_id INT,
    product_id INT,
    quantity INT,
    FOREIGN KEY (order_id)
    REFERENCES orders(order_id),
    FOREIGN KEY (product_id)
    REFERENCES products(product_id)
);

INSERT INTO customers VALUES
(1,'John Doe','New York','USA'),
(2,'Jane Smith','London','UK'),
(3,'Mary Johnson','Accra','Ghana');

INSERT INTO products VALUES
(101,'Laptop','Electronics',1200),
(102,'Phone','Electronics',800),
(103,'Desk Chair','Furniture',250);

INSERT INTO orders VALUES
(1001,1,'2025-01-05'),
(1002,2,'2025-01-10'),
(1003,3,'2025-01-15');

INSERT INTO order_details VALUES
(1,1001,101,2),
(2,1002,102,1),
(3,1003,103,4);

SELECT * FROM customers;

SELECT *
FROM customers
WHERE country = 'Ghana';

SELECT *
FROM products
ORDER BY price DESC;

SELECT SUM(p.price * od.quantity) AS total_revenue
FROM order_details od
JOIN products p
ON od.product_id = p.product_id;

SELECT AVG(price) AS average_price
FROM products;

SELECT
    p.category,
    SUM(p.price * od.quantity) AS revenue
FROM products p
JOIN order_details od
ON p.product_id = od.product_id
GROUP BY p.category;

SELECT
    c.customer_name,
    o.order_id,
    o.order_date
FROM customers c
INNER JOIN orders o
ON c.customer_id = o.customer_id;

SELECT
    c.customer_name,
    o.order_id
FROM customers c
LEFT JOIN orders o
ON c.customer_id = o.customer_id;

SELECT
    c.customer_name,
    o.order_id
FROM customers c
RIGHT JOIN orders o
ON c.customer_id = o.customer_id;

SELECT customer_id
FROM orders
WHERE order_id IN
(
    SELECT order_id
    FROM order_details
    WHERE quantity >
    (
        SELECT AVG(quantity)
        FROM order_details
    )
);

CREATE VIEW sales_summary AS
SELECT
    p.product_name,
    SUM(od.quantity) AS total_quantity,
    SUM(p.price * od.quantity) AS revenue
FROM products p
JOIN order_details od
ON p.product_id = od.product_id
GROUP BY p.product_name;

SELECT * FROM sales_summary;

CREATE INDEX idx_customer
ON orders(customer_id);

CREATE INDEX idx_product
ON order_details(product_id);

SELECT
    p.product_name,
    SUM(od.quantity) AS units_sold
FROM products p
JOIN order_details od
ON p.product_id = od.product_id
GROUP BY p.product_name
ORDER BY units_sold DESC;

SELECT
    c.customer_name,
    SUM(p.price * od.quantity) AS total_spent
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
JOIN order_details od ON o.order_id = od.order_id
JOIN products p ON od.product_id = p.product_id
GROUP BY c.customer_name
ORDER BY total_spent DESC;

